# administracion.py
from .base_datos import socios

class Administracion:
    def __init__(self):
        self.socios = socios

    def __str__(self):
        if not self.socios:
            return "No hay socios registrados en el sistema."
        socios_str = "Socios Registrados:\n"
        for socio in self.socios:
            socios_str += f"- {socio['socio']}\n"
        return socios_str

    def validar_usuario(self, usuario: str) -> bool:
        if not usuario.isalpha() or not (3 < len(usuario) < 12):
            print("El usuario debe contener solo letras y tener entre 4 y 11 caracteres. Intente nuevamente")
            return False
        return True

    def validar_contraseña(self, contraseña: str) -> bool:
        if not contraseña.isdigit() or not (4 < len(contraseña) < 9):
            print("La contraseña debe ser numérica y tener entre 5 y 8 dígitos. Intente nuevamente")
            return False
        return True

    def pedir_usuario(self) -> str:
        while True:
            usuario = input("Ingrese el nombre de usuario: ").lower()
            if usuario in [s['socio'] for s in self.socios]:
                print("🚨 Este usuario ya está registrado. Intente con otro nombre.")
                continue
            if self.validar_usuario(usuario):
                return usuario

    def pedir_contraseña(self) -> int:
        while True:
            contraseña = input("Ingrese la contraseña del asociado: ")
            if self.validar_contraseña(contraseña):
                return int(contraseña)

    def registro_socio(self):
        usuario = self.pedir_usuario()
        contraseña = self.pedir_contraseña()
        self.socios.append({'socio': usuario, 'contraseña': contraseña})
        print(f"✔️ El socio {usuario} ha sido registrado correctamente.")

    def publica_socios(self):
        if self.socios:
            print("\nListado de socios registrados:")
            for socio in self.socios:
                print(f"Socio: {socio['socio']}, Contraseña: {socio['contraseña']}")
        else:
            print("🚨 No hay socios registrados aún.")

    def acceso_socios(self):
        usuario = input("Ingrese el usuario del socio: ").lower()
        contraseña = int(input("Ingrese la contraseña del socio: "))
        for socio in self.socios:
            if socio['socio'] == usuario and socio['contraseña'] == contraseña:
                print(f"✔️ Bienvenido {usuario} 👋")
                return
        print("❌ La contraseña no coincide o el usuario no existe.")

    def elimina_socio(self):
        usuario = input("Ingrese el usuario del socio a eliminar: ").lower()
        for i, socio in enumerate(self.socios):
            if socio['socio'] == usuario:
                del self.socios[i]
                print(f"✔️ El socio {usuario} ha sido eliminado correctamente.")
                return
        print("🚨 Usuario no encontrado.")

def menu(admin: Administracion):
    """Menú para la gestión de socios."""
    while True:
        print("\n1. Registrar Socio\n2. Publicar Socios\n3. Acceso de Socios\n4. Eliminar Socio\n5. Salir")
        opción = input("Seleccione una opción: ")
        if opción == '1':
            admin.registro_socio()
        elif opción == '2':
            admin.publica_socios()
        elif opción == '3':
            admin.acceso_socios()
        elif opción == '4':
            admin.elimina_socio()
        elif opción == '5':
            print("Gracias por usar nuestro sistema. ¡Hasta la próxima! 😊")
            break
        else:
            print("Opción no válida, intente de nuevo.")

def main():
    admin = Administracion()
    print(admin)
    menu(admin)


