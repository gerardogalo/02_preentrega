socios = [
    {"socio": "lionel", "contraseña": "101010"},
    {"socio": "lucas", "contraseña": "123456"},
]
