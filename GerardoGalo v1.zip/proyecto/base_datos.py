socios = [
    {"nombre": "juancito", "contraseña": "123456", "email": "juan@mail.com", "activo": True, "edad": 28},
    {"nombre": "messi", "contraseña": "101010", "email": "messi@mail.com", "activo": True, "edad": 35},
    {"nombre": "lionel", "contraseña": "111111", "email": "lionel@mail.com", "activo": True, "edad": 22},
    {"nombre": "andres", "contraseña": "987654", "email": "andres@mail.com", "activo": False, "edad": 18}
]
